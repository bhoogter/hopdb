<style>

@media (min-width: 1100px) 
{
	.ihop-ad {
		position:relative;
		display: block;
		left: 500px;
		top: -125px;
		width: 500px;
		height: 100px;
	}
}
	
@media (max-width: 1099px)
{
	.ihop-ad {display: none;}
}
</style>

			<div class='ihop-ad'>
				<?php echo do_shortcode(" [adrotate group='1'] "); ?>
			</div>
