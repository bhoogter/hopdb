=== Plugin Name ===
Contributors: bhoogterp
Donate link: http://www.ihopnetwork.org/
Tags: hopdb, house of prayer, house of prayer database
Requires at least: 3.2.1
Tested up to: 3.2
Stable tag: 3.2

This plugin is to catalog a list of hosues of prayer, allowing user submission and revisions.

== Description ==

To facilitate house of prayer networks across the globe to connect worshippers with places to worship.

 - Separate user submission table (to help keep spam entries separate from real ones)
 - XML/KML feeds
 - User editable hops with master password.
 - Imitation Captcha Support
 - Statistics Widget

== Installation ==

1. Upload to plugins directory
2. Either activate as a Widget or as a short-code
3. go to your widget interface


== Frequently Asked Questions ==


Question or idea?

use [Support](benjaminhoogterp@gmail.com)

== Screenshots ==

1. Options
